﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Ed.Web.Areas.Tools.Controllers
{
    public class CaptureUploadController : Controller
    {



        //
        // GET: /Tools/CaptureUpload/

        public ActionResult Index()
        {
            return View();
        }

    }
}
