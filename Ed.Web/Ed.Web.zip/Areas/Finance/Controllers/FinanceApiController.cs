﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Ed.Web.Areas.Finance.Controllers
{
    public class FinanceApiController : ApiController
    {
    }
}
